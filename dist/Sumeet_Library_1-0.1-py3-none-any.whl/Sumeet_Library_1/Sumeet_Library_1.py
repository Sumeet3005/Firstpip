class Sumeet_Lib:
    print('Thank You for Using My Very First trial, Unfortunately Library making is in progress')
    
        
  
